# Post-migration fixes (deferred, NOT applied in Phase 2j)

Owner decision 4/5: the cart page's `ctState.items`, `discount` and `tax` quirks are **kept
exactly as legacy** in Phase 2j. They are genuine legacy bugs, so they must not be "fixed" during
the migration (AGENTS.md rule 10: do not delete or fix things you don't understand). This file is
the place to record them so they can be decided and fixed **after** the migration is complete and
the new pages are live.

Each entry: what the bug is, where it lives, why it is preserved, and the fix to consider.

---

## 1. `ctState.items` is never assigned → coupon subtotal is always 0

- **Legacy:** `js/cart-page.js` — `ctState.items` is read by `applyCouponFromSheet` (≈ L3210) to
  build the coupon `subtotal`, but **nothing ever assigns `ctState.items`**. The coupon payload
  therefore always sends `subtotal: 0`.
- **Ported as:** `web/lib/cart-page-state.ts` — `ctState.items` stays unset; the same dead read is
  kept.
- **Effect:** a percentage/free-item coupon that is validated against a subtotal cannot work
  correctly. This is a real user-visible bug, not a cosmetic one.
- **Considered fix (post-migration):** set `ctState.items` in `paintBill`/`renderCart` (or compute
  the subtotal directly in `applyCouponFromSheet` from `readCart()`), then re-verify the coupon
  flow end to end against the backend.

## 2. `ctState.discount` is read but never set (dead read)

- **Legacy:** `applyTotals` (≈ L855) reads `Number(ctState.discount || 0)` and only shows the
  "Extra discount for you" row when it is > 0. `ctState.discount` is never assigned anywhere, so
  the row is effectively always hidden / `-₹0`.
- **Ported as:** `web/lib/cart-page-state.ts` — identical dead read kept, with a comment.
- **Considered fix (post-migration):** decide whether a discount is meant to come from the coupon
  response; if so, assign `ctState.discount` there and re-test the bill.

## 3. `ctState.tax` is read but never set (dead read)

- **Legacy:** `applyTotals` (≈ L862) reads `Number(ctState.tax || 0)` and shows the
  "Government Taxes" row only when > 0 (formatted with `toFixed(2)`). Never assigned.
- **Ported as:** `web/lib/cart-page-state.ts` — identical dead read kept, with a comment.
- **Considered fix (post-migration):** if taxes are meant to be charged, source them from the
  backend order/total and set `ctState.tax`; otherwise delete the row from the markup.

## 4. Delivery-fee tiers 40 and 50 are unreachable

- **Legacy:** `deliveryFeeForDistance` returns 30 (< 10 km), 40 (≤ 15 km) or 50 (else), but the
  delivery radius is capped at 10 km (cart-page ≈ L302/L347), so 40 and 50 never occur.
- **Ported as:** `web/lib/cart-page-state.ts` — all three tiers kept (owner decision 3).
- **Considered fix (post-migration):** either keep (harmless) or align the tiers with the real
  radius cap once delivery pricing is reviewed.

## 5. C7 `ctaBlock()` is never called by legacy `cart-page.js` (dead code)

- **Legacy:** `js/cart-checkout-upgrades.js` L95–99 defines `ctaBlock()` (maintenance / shortage CTA labels) and
  exports it on `window.CtX`, but no caller exists anywhere in `cart.html`, `js/cart-page.js` or the other scripts.
  The CTA is blocked in practice only through `CtX.revalidateBeforeOrder()` (cart-page.js L1675–1676), which runs
  immediately before `POST /orders`.
- **Ported as:** `web/lib/cart-checkout-upgrades.ts` — `ctaBlock()` kept and exported (dead, exactly like legacy).
- **Considered fix (post-migration):** either wire `ctaBlock()` into the checkout button (maintenance / shortage
  labels) or delete it; decide with the owner.

## 6. `#ct-fd-progress` is inserted lazily, after `#free-delivery-nudge`

- **Legacy:** `paintFreeDelivery` (cart-checkout-upgrades L424–438) creates `#ct-fd-progress` on first paint and
  inserts it with `insertBefore(host, anchor.nextSibling)` right after `#free-delivery-nudge`. Until then the node
  does not exist, so a naive snapshot of the DOM before the first bill paint shows no `#ct-fd-progress`.
- **Ported as:** `web/lib/cart-checkout-upgrades.ts` — identical lazy insert (id + class + position preserved).
- **Effect:** none for users; test harnesses must paint the bill before asserting the node exists.

## 7. COD cap defaults to 1000 when `maxCodOrderAmount` is 0/absent

- **Legacy:** `codState()` (L101–116) uses `n(s.maxCodOrderAmount) > 0 ? n(s.maxCodOrderAmount) : 1000`, so a
  platform payload that omits the cap still enforces ₹1000.
- **Ported as:** identical (kept).
- **Effect:** the "Available for orders up to ₹1000" note appears even when the backend did not send a cap.

---

_Anything fixed here must be re-verified with `web/scripts/cart-money-parity.mjs` and the
restaurant-shell money harness, and noted in PROGRESS.md._
