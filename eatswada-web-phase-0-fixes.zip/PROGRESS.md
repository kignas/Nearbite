# EatSwada migration — PROGRESS

## 2026-10-26 Task: Phase 0 fixes (Tailwind reset, gated redirects, compare script)

Files changed:
- `web/app/globals.css` — replaced the create-next-app starter CSS with the Tailwind
  theme + utilities layer imports only. `@import "tailwindcss"` (which pulls in preflight)
  is gone, so the legacy CSS files render unchanged.
- `web/app/layout.tsx` — removed the Geist font imports and the starter `<html>`/`<body>`
  classes; metadata title is now "EatSwada".
- `web/app/page.tsx` — starter content removed; returns `null` (placeholder).
- `web/next.config.js` — redirects are now data-driven (`PORTED_PAGES` + `LEGACY_HTML`).
- `web/scripts/compare.mjs` — **new**, unchanged copy of `tools/compare.mjs`.
- `web/package.json` — added `"compare": "node scripts/compare.mjs"`.
- `PROGRESS.md` — **this file**.

CSS import order:
Not applicable yet — no page was built in this task. Per-page order is recorded when each
page is ported (AGENTS.md hard rule 2). The global layer statement is now
`@layer theme, base, components, utilities;` and Tailwind contributes only `theme` and
`utilities` (no `base`, so no preflight reset).

Compare result:
No page to compare. The `compare` script itself was sanity-checked against one URL twice
(`about.html` vs `about.html`) from `web/`:
phone 0.00% / desktop 0.00% — PASS. Real per-page results start in Phase 1.

compare.mjs usage line (do not rewrite the script):
`cd web && npm run compare -- <legacyUrl> <newUrl> <name>`
(equivalently `node scripts/compare.mjs <legacyUrl> <newUrl> <name>`). It resolves
`playwright`/`pixelmatch`/`pngjs` from `web/node_modules`, so it must be run from `web/`.
There is no root `package.json` and no symlink (as instructed); the previous open question
about module resolution is now resolved by running from `web/`.

Redirects are data-driven:
`next.config.js` has `const PORTED_PAGES = []` at the top and a `LEGACY_HTML` table mapping
every legacy `*.html` file to its clean URL. A legacy URL only 301-redirects once its clean
page is in `PORTED_PAGES`. **Each phase must append its pages to `PORTED_PAGES`.**
Always on, regardless of `PORTED_PAGES`:
- `/restaurant.html` → `/restaurant` (301)
- rewrites `/restaurant` → `/api/restaurant-seo` and `/sitemap-restaurants.xml` → `/api/sitemap`
- `X-Robots-Tag: noindex, nofollow` on `/restaurant-shell` and `/restaurant-shell.html`
`restaurant old.html` → `/restaurant` and `track-order-10.html` → `/track-order`, both active
only once `/restaurant` and `/track-order` are in `PORTED_PAGES`.

Tested behaviours:
- `cd web && npm run build` — passes, no errors.
- Generated CSS (`.next/static/chunks/*.css`, 457 bytes) contains the Tailwind `theme` layer
  and only the utilities in use; the preflight reset (`box-sizing: border-box`,
  `-webkit-text-size-adjust`, `img { display: block }`) is **absent**, confirming the legacy
  design is untouched.
- With `PORTED_PAGES = []` (live `next start`): only `/restaurant.html` → 301; `/about.html`,
  `/index.html`, `/restaurant%20old.html`, `/track-order-10.html`, `/restaurant-shell.html`
  all 404 (not ported yet, expected); noindex header still present; both rewrites registered.
- Gating verified by temporarily setting `PORTED_PAGES = ["/restaurant", "/track-order"]`:
  `/restaurant.html`, `/restaurant%20old.html` → 301 `/restaurant`; `/track-order.html`,
  `/track-order-10.html` → 301 `/track-order`; `/about.html` still 404. Then reverted to `[]`.
- `cd web && npm run compare -- <url> <url> sanity` — 0.00% / 0.00%, PASS.
- `git check-ignore` confirms `web/.gitignore` ignores `node_modules`, `.next` and `.env*`.

Open questions / TODOs:
- `TODO(question)`: `restaurant old.html` and `track-order-10.html` are on the AGENTS.md skip
  list yet now map to `/restaurant` and `/track-order` (per this task's instruction). They are
  not copied into `web/`; they only redirect once those pages are ported.
- `TODO(question)`: branches `poc/app-shell` and `stage-3-home-banners` contain a separate
  `modern-shell/` React 19 + **Vite 7** prototype (Home/Orders nav shell), unrelated to the
  Next.js app and marked do-not-merge in its README. Ignored here; flag if it is meant to be
  used as a reference for later phases.
- Env var NAMES the owner must set in `web/.env.local` (no values are printed here):
  `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_BRAND_NAME`, `NEXT_PUBLIC_MAPTILER_ENABLED`,
  `NEXT_PUBLIC_MAPTILER_KEY`, `NEXT_PUBLIC_MAPTILER_MAP_ID`, `NEXT_PUBLIC_FIREBASE_ENABLED`,
  `NEXT_PUBLIC_FIREBASE_API_KEY`, `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`,
  `NEXT_PUBLIC_FIREBASE_PROJECT_ID`, `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`,
  `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`.

## 2026-10-26 Task: Phase 0 — Next.js scaffold (no pages)
(superseded in part by the "Phase 0 fixes" task above — see that section for the current
globals.css, redirect model and compare-script location.)

Files changed:
- `web/` — new Next.js 16.4.3 app (App Router, TypeScript, Tailwind 4, ESLint, no `src/`).
- `web/next.config.js` — **new** (ported from legacy `vercel.json`; replaces the generated
  `next.config.ts`, which was deleted). Holds the redirects, both rewrites and the
  noindex headers.
- `web/.env.local` — **new**, values moved out of legacy `config.js` (git-ignored).
- `web/lib/config.ts` — **new**, reads the `NEXT_PUBLIC_*` vars; mirrors the legacy `CONFIG` shape.
- `web/lib/api.ts` — **new**, line-for-line port of legacy `api.js`.
- `web/styles/legacy/*.css` (20) + `web/styles/legacy/css/*.css` (54) — copied byte-for-byte.
- `web/public/` — `*.svg *.png *.webp *.ico robots.txt firebase-messaging-sw.js` copied.
- `tools/compare.mjs` — **not touched** (owner committed it); devDeps it needs were installed.
- `notes/phase-0-notes.md` — **new**.
- `PROGRESS.md` — **new** (this file).

CSS import order:
Not applicable yet — no page was built in this task. Per-page order is recorded when each
page is ported (AGENTS.md hard rule 2).

Compare result:
No page to compare. The tool itself was sanity-checked against one URL twice:
`about.html` phone 0.00% / desktop 0.00% — PASS. Real per-page results start in Phase 1.

compare.mjs usage line (do not rewrite the script):
`cd web && npm run compare -- <legacyUrl> <newUrl> <name>` — see the "Phase 0 fixes" section
above for the resolution details. (The initial run used a temporary repo-root symlink; the
current, committed approach is the `web/scripts/compare.mjs` copy plus the npm script.)

Tested behaviours:
- `cd web && npm run build` — passes, no errors (only `/` and `/_not-found` routes exist).
- `npx tsc --noEmit` — clean.
- Live `next start` checks (at the time, all 40 redirects were unconditional):
  - all 40 legacy `*.html` URLs → HTTP **301** with the correct clean `location`
    (scripted check of every file, including `/restaurant%20old.html`).
  - `/restaurant-shell` and `/restaurant-shell.html` → `X-Robots-Tag: noindex, nofollow`.
  - rewrites `/restaurant` → `/api/restaurant-seo` and `/sitemap-restaurants.xml` → `/api/sitemap`
    are registered (both 404 today because no route exists yet — expected in Phase 0).
  - `/robots.txt` and `/firebase-messaging-sw.js` served from `public/` (200).

Open questions / TODOs:
- Resolved by the "Phase 0 fixes" task: compare.mjs module resolution (now run from `web/`);
  the two skip-list redirects (now `/restaurant` and `/track-order`, gated by `PORTED_PAGES`).
- `TODO(question)`: branches `poc/app-shell` and `stage-3-home-banners` contain a separate
  `modern-shell/` React 19 + **Vite 7** prototype (Home/Orders nav shell), unrelated to the
  Next.js app and marked do-not-merge in its README. Ignored here; flag if it is meant to be
  used as a reference for later phases.
- Env var NAMES the owner must set in `web/.env.local` (no values are printed here):
  `NEXT_PUBLIC_API_BASE_URL`, `NEXT_PUBLIC_BRAND_NAME`, `NEXT_PUBLIC_MAPTILER_ENABLED`,
  `NEXT_PUBLIC_MAPTILER_KEY`, `NEXT_PUBLIC_MAPTILER_MAP_ID`, `NEXT_PUBLIC_FIREBASE_ENABLED`,
  `NEXT_PUBLIC_FIREBASE_API_KEY`, `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`,
  `NEXT_PUBLIC_FIREBASE_PROJECT_ID`, `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`,
  `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`.
