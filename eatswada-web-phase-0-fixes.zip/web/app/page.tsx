export default function Home() {
  // Placeholder. Each phase replaces this with the ported page.
  return null;
}
