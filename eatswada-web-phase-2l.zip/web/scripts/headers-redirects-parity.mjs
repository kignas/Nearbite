// Phase 2h — headers + redirects + status-code parity vs legacy `vercel.json`
// and `api/restaurant-seo.js`.
//
// Usage: node scripts/headers-redirects-parity.mjs [newOrigin]
const NEW = (process.argv[2] || "http://localhost:3000").replace(/\/$/, "");
const ID = "6ac8f95828669b5f4e30f0ba";
let checks = 0, fails = 0;
const ok = (cond, label) => { checks++; if (!cond) { fails++; console.log("  FAIL " + label); } else console.log("  pass " + label); };

const head = async (p) => { const r = await fetch(NEW + p, { redirect: "manual" }); return r; };

console.log("== cleanUrls redirects (legacy vercel.json cleanUrls:true) ==");
for (const [file, clean] of [
  ["/restaurant-shell.html", "/restaurant-shell"],
  ["/under99.html", "/under99"],
  ["/category.html", "/category"],
  ["/search.html", "/search"],
  ["/index.html", "/"],
]) {
  const r = await head(file);
  ok(r.status === 301, `${file} -> 301`);
  ok((r.headers.get("location") || "").endsWith(clean), `${file} -> ${clean}`);
}
{
  const r = await head("/restaurant.html");
  ok(r.status === 301 && (r.headers.get("location") || "").endsWith("/restaurant"), "/restaurant.html -> 301 /restaurant (explicit vercel redirect)");
}

console.log("== X-Robots-Tag (legacy vercel headers) ==");
{
  const r = await head("/restaurant-shell");
  ok(r.status === 200, "/restaurant-shell 200");
  ok((r.headers.get("x-robots-tag") || "").toLowerCase().includes("noindex"), "/restaurant-shell X-Robots-Tag noindex, nofollow");
}
{
  const r = await head(`/restaurant?id=${ID}`);
  ok(r.status === 200, "/restaurant valid id 200");
  ok(!r.headers.get("x-robots-tag"), "/restaurant has NO X-Robots-Tag (indexable URL)");
  ok((r.headers.get("cache-control") || "").includes("s-maxage=300"), "/restaurant Cache-Control matches legacy");
}

console.log("== status codes (legacy api/restaurant-seo.js) ==");
ok((await head("/restaurant")).status === 404, "missing id -> 404");
ok((await head("/restaurant?id=short")).status === 404, "invalid id -> 404");
ok((await head(`/restaurant?id=${ID}`)).status === 200, "eligible id -> 200");
ok((await head("/restaurant?id=6ac5cbd0933976c30865d23e")).status === 404, "NEVER_INDEX test id -> 404");

console.log("== xml / pwa ==");
{
  const r = await head("/sitemap-restaurants.xml");
  ok(r.status === 200 && (r.headers.get("content-type") || "").includes("xml"), "/sitemap-restaurants.xml 200 xml");
}
{
  const r = await head("/sitemap.xml");
  ok(r.status === 200 && (r.headers.get("content-type") || "").includes("xml"), "/sitemap.xml 200 xml");
}
{
  const r = await head("/manifest.webmanifest");
  ok(r.status === 200, "/manifest.webmanifest 200");
}
{
  const r = await head("/robots.txt");
  ok(r.status === 200, "/robots.txt 200");
}
{
  const r = await head("/sw.js");
  ok(r.status === 200, "/sw.js 200");
}
{
  const r = await head("/firebase-messaging-sw.js");
  ok(r.status === 200, "/firebase-messaging-sw.js 200 (exact root path)");
}

console.log(`\n${checks - fails}/${checks} checks PASS`);
process.exit(fails ? 1 : 0);
