/* ================================================================
   EATSWADA — SHARED SITE FOOTER
   ----------------------------------------------------------------
   Byte-for-byte port of the `<footer class="ew-site-footer">` block that is
   identical across the 12 legacy pages that carry it (about, faq, legal,
   privacy-data, support, terms, refund-policy, rate-us, order-help,
   delivery-areas-and-charges, partner-with-us, food-delivery-in-maynaguri).

   Styled by `styles/legacy/css/eatswada-site-footer.css` (unchanged).
   ================================================================ */

export default function Footer() {
  return (
    <footer className="ew-site-footer" aria-label="Eatswada site footer">
      <div className="ew-footer-inner">
        <nav className="ew-footer-grid" aria-label="Footer navigation">
          <section className="ew-footer-group">
            <h2>Company</h2>
            <ul>
              <li>
                <a href="/about">About Eatswada</a>
              </li>
              <li>
                <a href="/support">Contact us</a>
              </li>
              <li>
                <a href="mailto:hello@eatswada.com">General enquiries</a>
              </li>
            </ul>
          </section>
          <section className="ew-footer-group">
            <h2>For customers</h2>
            <ul>
              <li>
                <a href="/support">Help &amp; support</a>
              </li>
              <li>
                <a href="/faq">FAQs</a>
              </li>
              <li>
                <a href="/order-help">Order help &amp; issue reporting</a>
              </li>
              <li>
                <a href="/delivery-areas-and-charges">
                  Delivery areas &amp; charges
                </a>
              </li>
              <li>
                <a href="/refund-policy">Refunds &amp; cancellations</a>
              </li>
            </ul>
          </section>
          <section className="ew-footer-group">
            <h2>For restaurants</h2>
            <ul>
              <li>
                <a href="/partner-with-us">Partner with us</a>
              </li>
              <li>
                <a href="mailto:hello@eatswada.com?subject=Restaurant%20enquiry">
                  Restaurant enquiries
                </a>
              </li>
            </ul>
          </section>
          <section className="ew-footer-group">
            <h2>Legal &amp; contact</h2>
            <ul>
              <li>
                <a href="/terms">Terms of Service</a>
              </li>
              <li>
                <a href="/legal#privacy">Privacy Policy</a>
              </li>
              <li>
                <a href="/privacy-data">Privacy &amp; Data</a>
              </li>
              <li>
                <a href="/refund-policy">Refund Policy</a>
              </li>
              <li>
                <a href="mailto:support@eatswada.com">support@eatswada.com</a>
              </li>
              <li>
                <a href="mailto:hello@eatswada.com">hello@eatswada.com</a>
              </li>
            </ul>
          </section>
        </nav>
        <div className="ew-footer-brand" aria-label="Eatswada">
          eats<span>wada</span>
        </div>
        <div className="ew-footer-bottom">
          <p>© 2026 Eatswada. All rights reserved.</p>
          <p>Serving Maynaguri, West Bengal.</p>
        </div>
      </div>
    </footer>
  );
}
