/* ================================================================
   EATSWADA — RESTAURANT SHELL PAGE  (`/restaurant-shell`)
   ----------------------------------------------------------------
   This route is the RAW shell: `X-Robots-Tag: noindex, nofollow` (set in
   `next.config.js` headers) and its own `noindex, nofollow` metadata plus the
   legacy canonical `https://eatswada.com/restaurant-shell.html`.

   The markup and CSS imports live in `components/RestaurantShell.tsx`, which is
   shared with `app/restaurant/page.tsx` so the two routes can never drift. This
   file only supplies the metadata.

   `/restaurant` is the ONLY indexed restaurant URL; it renders the same
   component with the SEO metadata from the SEO layer.
   ================================================================ */
import type { Metadata } from "next";
import RestaurantShell from "../../components/RestaurantShell";

export const metadata: Metadata = {
  /* Legacy `<title>Menu – EatSwada</title>`. `/restaurant` overwrites this with
     the restaurant name in the SEO layer. */
  title: "Menu – EatSwada",
  robots: { index: false, follow: false },
  alternates: { canonical: "https://eatswada.com/restaurant-shell.html" },
  /* Legacy line 13: <meta name="view-transition" content="same-origin"> */
  other: { "view-transition": "same-origin" },
  /* Legacy line 50: <meta name="twitter:card" content="summary"> */
  twitter: { card: "summary" },
};

export default function RestaurantShellPage() {
  return <RestaurantShell />;
}
